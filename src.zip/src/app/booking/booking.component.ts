import { Component, OnInit } from '@angular/core';
import { MoviesService } from '../movies.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss'],
})
export class BookingComponent implements OnInit {

  constructor(private moviesService:MoviesService, private route: ActivatedRoute, private router: Router) { }
  id: number;
  private sub: any;
  movie:any={};
  ngOnInit() {this.moviesService.getRemoteMovies().subscribe((result)=>this.movie=result);
    this.sub = this.route.params.subscribe(params => {
      this.id = +params['id']; // (+) converts string 'id' to a number
      console.log("id is "+this.id);
      this.moviesService.getRemoteMoviesById(this.id).subscribe((movie)=> {this.movie=movie;})

  });

  
  }

}
